'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _Promise = _interopDefault(require('babel-runtime/core-js/promise'));
var AWS = _interopDefault(require('aws-sdk'));
var lodash = require('lodash');

var ec2 = new AWS.EC2({
  apiVersion: '2016-11-15'
});

exports.main = function (event, context, callback) {
  console.log('Moneypenny: ', Date.now());

  getMoneypennyManagedInstances().then(function (res) {
    console.log(res, 'result');

    callback(null, res);
  });
};

function getMoneypennyManagedInstances() {
  var params = {
    Filters: [{
      Name: 'tag:Moneypenny',
      Values: ['managed']
    }]
  };

  return new _Promise(function (resolve, reject) {
    ec2.describeInstances(params, function (err, data) {
      if (err) reject(err);else resolve(data);
    });
  });
}
//# sourceMappingURL=index.js.map
